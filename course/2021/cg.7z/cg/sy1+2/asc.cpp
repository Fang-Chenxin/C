#include<stdio.h>
int main()
{
    char a,b,c;
    scanf("%c",&b);
    a=b-1;c=b+1;
    printf("%c %c %c\n",a,b,c);
    printf("%d %d %d",a,b,c);
}