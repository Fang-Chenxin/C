#include<stdio.h>
int main()
{printf("* * * *");
printf("* * *");
printf("* *");
printf("*");
 } 
