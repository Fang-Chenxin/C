#include <stdio.h>
int main()
{  
    printf("*************\n");
    printf("  Welcome\n");
    printf("*************\n");
    return 0;
}
