/*
 * File: fivetimes_plan_terminate.c
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 22-Nov-2022 12:18:24
 */

/* Include Files */
#include "fivetimes_plan_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void fivetimes_plan_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for fivetimes_plan_terminate.c
 *
 * [EOF]
 */
