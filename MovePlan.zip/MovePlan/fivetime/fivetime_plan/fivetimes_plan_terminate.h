/*
 * File: fivetimes_plan_terminate.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 22-Nov-2022 12:18:24
 */

#ifndef FIVETIMES_PLAN_TERMINATE_H
#define FIVETIMES_PLAN_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void fivetimes_plan_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for fivetimes_plan_terminate.h
 *
 * [EOF]
 */
